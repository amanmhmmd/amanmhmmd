export interface IUser {
  _id?: string;
  username: string;
  designation: string;
  department: string;
}
