export interface IRailForm {
  _id: string;
  board: string;
  section: string;
  mps: number;
  slots: {};
  directions: string[];
  stations: object;
}
